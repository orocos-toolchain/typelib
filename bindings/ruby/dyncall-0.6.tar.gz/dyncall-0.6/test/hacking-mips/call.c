void call_f0()
{
  n0();
}

void call_f4()
{
  n4(1,2,3,4);
}

void call_f8()
{
  n8(1,2,3,4,5,6,7,8);
}


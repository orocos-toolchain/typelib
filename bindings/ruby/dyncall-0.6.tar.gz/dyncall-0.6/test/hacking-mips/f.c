#include "common.h"
int f(int a0, int a1, int a2, int a3, int a4, int a5)
{
  return a0+a1+a2+a3+a4+a5;
}


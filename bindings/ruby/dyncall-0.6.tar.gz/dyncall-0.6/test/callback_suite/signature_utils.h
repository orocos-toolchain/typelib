const char* SignatureSkipCallPrefix(const char* signature);

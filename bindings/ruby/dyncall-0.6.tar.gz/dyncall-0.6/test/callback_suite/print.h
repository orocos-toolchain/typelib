void PrintUsage(const char* appname);
void PrintHeader();
void PrintCaseInfo(int index, const char* signature); 
void PrintCaseResult(int result);
void PrintTotalResult(int result);

const char* GetSignature(int index); /* index starts at 0 */

